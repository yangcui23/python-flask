class User:
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.account = BankAccount(
            int_rate=0.02, balance=0, saving_balance=0, checking_balance=0)

    def make_deposit(self, savings, checking):
        self.account.balance = savings + checking
        print(self.account.balance)
        self.account.saving_balance += savings
        print(self.account.saving_balance)
        self.account.checking_balance += checking
        print(self.account.checking_balance)

        return self

    def make_withdrawal(self, make_withdraw):
        self.account.balance -= make_withdraw
        return self

    def display_user_balance(self):
        print(self.account.balance)
        return self
    # def savings(self,savings):


class BankAccount:
    # don't forget to add some default values for these parameters!
    def __init__(self, int_rate, balance, saving_balance, checking_balance):
        self.int_rate = int_rate
        self.balance = balance
        self.saving_balance = saving_balance
        self.checking_balance = checking_balance

    def deposit(self, deposit_amount):
        self.balance = self.balance + deposit_amount
        print(f"Deposit : {deposit_amount}")

        return self

    def withdraw(self, withdraw_amount):
        self.balance = self.balance - withdraw_amount
        print(f"withdraw {withdraw_amount}")
        if self.balance < withdraw_amount:
            print("Insufficient funds : Charging a $5 fee")
            self.balance -= 5

        return self

    def display_account_info(self):
        print(f"Balance : {self.balance}")
        print(f"Account balance {self.balance}")

        return self

    def yield_interest(self):
        self.balance = self.balance * self.int_rate
        return self


# yangsAccount = BankAccount(2.5, 0)

# johnsAccount = BankAccount(1.8, 0)

# yangsAccount.deposit(500).deposit(300).deposit(
#     50).withdraw(1000).yield_interest().display_account_info()

# johnsAccount.deposit(300).deposit(500).withdraw(200).withdraw(
#     400).withdraw(30).withdraw(150).yield_interest().display_account_info()

yang = User("Yang", "yangcui283@yahoo.com")
# yang.make_withdrawal(500).display_user_balance()
yang.make_deposit(800, 400).make_withdrawal(500).display_user_balance()
# yang.deposit(500).display_account_info()
# yang = BankAccount(1.5, 0)
