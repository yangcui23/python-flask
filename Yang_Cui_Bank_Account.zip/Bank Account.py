

class BankAccount:
    # don't forget to add some default values for these parameters!
    def __init__(self, int_rate, balance):
        self.int_rate = int_rate
        self.balance = balance

    def deposit(self, deposit_amount):
        self.balance = self.balance + deposit_amount
        print(f"Deposit : {deposit_amount}")

        return self

    def withdraw(self, withdraw_amount):
        self.balance = self.balance - withdraw_amount
        print(f"withdraw {withdraw_amount}")
        if self.balance < withdraw_amount:
            print("Insufficient funds : Charging a $5 fee")
            self.balance -= 5

        return self

    def display_account_info(self):
        print(f"Balance : {self.balance}")
        print(f"Account balance {self.balance}")

        return self

    def yield_interest(self):
        self.balance = self.balance * self.int_rate
        return self


yangsAccount = BankAccount(2.5, 0)

johnsAccount = BankAccount(1.8, 0)

yangsAccount.deposit(500).deposit(300).deposit(
    50).withdraw(1000).yield_interest().display_account_info()

johnsAccount.deposit(300).deposit(500).withdraw(200).withdraw(
    400).withdraw(30).withdraw(150).yield_interest().display_account_info()
