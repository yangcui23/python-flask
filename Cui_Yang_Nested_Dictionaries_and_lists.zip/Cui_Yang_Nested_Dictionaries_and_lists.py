x = [[5, 2, 3], [10, 8, 9]]
x[1][0] = 15
print(x)


students = [
    {'first_name':  'Michael', 'last_name': 'Jordan'},
    {'first_name': 'John', 'last_name': 'Rosales'}
]
students[1]["last_name"] = 'Bryant'


sports_directory = {
    'basketball': ['Kobe', 'Jordan', 'James', 'Curry'],
    'soccer': ['Messi', 'Ronaldo', 'Rooney']
}
sports_directory['soccer'][0] = 'Andres'
print(sports_directory)


z = [{'x': 10, 'y': 20}]

z[0]['y'] = 30
print(z)


students = [
    {'first_name':  'Michael', 'last_name': 'Jordan'},
    {'first_name': 'John', 'last_name': 'Rosales'},
    {'first_name': 'Mark', 'last_name': 'Guillen'},
    {'first_name': 'KB', 'last_name': 'Tonel'}
]


def iterateDictionary(students):
    for i in range(len(students)):

        print(
            f"first_name - {students[i]['first_name']} , last_name - {students[i]['last_name']}", )


iterateDictionary(students)


# should output: (it's okay if each key-value pair ends up on 2 separate lines;
# bonus to get them to appear exactly as below!)
# first_name - Michael, last_name - Jordan
# first_name - John, last_name - Rosales
# first_name - Mark, last_name - Guillen
# first_name - KB, last_name - Tonel


def iterateDictionary2(key_name, students):
    for i in range(len(students)):
        for key in students[i]:
            if key == key_name:
                print(students[i][key_name])


iterateDictionary2('first_name', students)
iterateDictionary2('last_name', students)


dojo = {
    'locations': ['San Jose', 'Seattle', 'Dallas', 'Chicago', 'Tulsa', 'DC', 'Burbank'],
    'instructors': ['Michael', 'Amy', 'Eduardo', 'Josh', 'Graham', 'Patrick', 'Minh', 'Devon']
}


def printInfo(some_dict):

    print(len(some_dict['locations']), "LOCATIONS")

    for i in some_dict['locations']:

        print(i)

    

    print(len(some_dict['instructors']), "INSTRUCTORS")

    for j in some_dict['instructors']:

        print(j)

printInfo(dojo)
